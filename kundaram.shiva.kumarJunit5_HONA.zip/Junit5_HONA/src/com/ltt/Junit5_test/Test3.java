package com.ltt.Junit5_test;

public @interface Test3 {

}
