package com.ltt.Junit5_test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ltt.Junit5.LogicBuild;

class MyTest {
private static final String Null = null;
	//	private static final String Null = null;
	LogicBuild logicbuild;
	@BeforeAll
	static void beforeall()
	{
		System.out.println("Before All Tests");
		
	}
	 
	@BeforeEach
	void setUp()throws Exception{
		logicbuild= new LogicBuild();
		System.out.println("Before Each Tests");
	}
	@Test
	void test() {
		assertEquals("Login SuccessFull",logicbuild.correct("kundaramshivakumar","1234"));
		System.out.println("Login SuccessFull");
		
	}
	@Test
	void test2()
	{
		assertNotEquals("Login Failure", logicbuild.correct("kundaramshivakumar","1234"));
		System.out.println("Login Failure");
		
	}
	@Test
	void test3()
	{
		assertNotNull("UserName Or Password are Null",logicbuild.IsNull(Null,Null));
		System.out.println("UserName Or Password are Null");
//		assertNull("password123");
		
	}
	
	@Test
	void test4()
	{
		assertEquals("UserName Or Password are Empty",logicbuild.IsEmpty("",""));
	}
	@AfterEach
	void tests()
	{
		System.out.println("After Each Test");
	}
	
	@AfterAll
	static void IsEmpty() {
		System.out.println("After All Tests");
	}
	

}
