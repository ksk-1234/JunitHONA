package com.ltt.Junit5;

public class LogicBuild {
	
		public static String correct(String uname, String pwd)
		{
			String Us="kundaramshivakumar";
			String pw="1234";
			String res="";
			if(Us==uname)
			{
				
				if(pw==pwd)
				{
					res="Login SuccessFull";
				}
				else
				{
					res="Login Failure";
				}
			}
			else 
			{
				res="Login Failure";
			}
			return res;
		}
		
		public static String IsNull(String uname, String pwd)
		{
			String res="";
			if(uname==null || pwd==null)
			{
				res="UserName Or Password are Null";
			}
			return res;
		}
		
		public static String IsEmpty(String uname, String pwd)
		{
			String res="";
			if(uname=="" || pwd=="")
			{
				res="UserName Or Password are Empty";
			}
			return res;
		}
		
}
